#pragma once

#include "colisiones.h"
/*
class GameObject
{
private:
	// ...
public:
	Collider collider;

	void ApplyCollision(Collision c) {}
	void ApplyAcceleration(Vector2 a) {}
};

class Player : public GameObject
{
};

class Enemy : public GameObject
{
};

class Projectile : public GameObject
{
};*/